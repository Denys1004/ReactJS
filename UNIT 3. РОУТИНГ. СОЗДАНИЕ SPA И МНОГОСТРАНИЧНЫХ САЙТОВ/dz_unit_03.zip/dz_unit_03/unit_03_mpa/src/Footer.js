function Footer(){
    return(
        <footer>Footer</footer>
    )
}

export default Footer;